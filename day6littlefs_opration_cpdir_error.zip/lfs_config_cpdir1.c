#include <unistd.h>
#include "lfs_config.h"

lfs_file_t file;

lfs_t little_fs = {0};

lfs_dir_t dir_data;
struct lfs_info dirlfsinfo;

static uint8_t fine_file_flag = 0;

static uint8_t read_buffer[LITTLE_FS_READ_SIZE];
static uint8_t program_buffer[LITTLE_FS_PROGRAM_SIZE];
static uint8_t lookahead_buffer[LITTLE_FS_MAX_LOOKAHEAD / 8];	//16

static struct lfs_config little_fs_config = {
   .read = littlfs_read,
   .prog = littlfs_program,
   .erase = littlfs_erase,
   .sync = littlfs_sync,
   
   .read_size = LITTLE_FS_READ_SIZE,   //读
   .prog_size = LITTLE_FS_PROGRAM_SIZE,   //写
   .block_size = LITTLE_FS_BLOCK_SIZE, //块大小	2^12 = 4096
   .block_count = LITTLE_FS_MAX_BLOCK_COUNT,	//block块的数量 
   //总的大小为: block_count * block_size = 4096 * 2^6 = 2^18

   //用于标记block的bit数 每一个block需要1bit作为标记	且要求为32的倍数
   //即需要lookahead >= block_count;
   .lookahead = LITTLE_FS_MAX_LOOKAHEAD,
   
   .read_buffer = read_buffer,
   .prog_buffer = program_buffer,
   //一个字节8bit位,根据lookahead需要多少的bit位得出需要的字节数大小	即
   //lookahead_buffer=lookahead/8 + 1
   .lookahead_buffer = lookahead_buffer,
};

int mount_init(lfs_t* little_fs, struct lfs_config* little_fs_config)
{
	int mount_ret = lfs_mount(little_fs, little_fs_config);   //挂载littlefs
	if (mount_ret != LFS_ERR_OK)   //挂载失败
	{
		// sFLASH_NOR_ChipErase();
		const int format_ret = lfs_format(little_fs, little_fs_config); //使用littlefs格式化块设备
		if (format_ret != LFS_ERR_OK) //littlefs格式化块设备失败
		{
		  printf("lfs_format error=%d\n", format_ret);
		}
		mount_ret = lfs_mount(little_fs, little_fs_config);
		if (mount_ret != LFS_ERR_OK)
		{
		  printf("lfs_mount 2 error=%d\n", mount_ret);
		}
	}

   return mount_ret;
}


int main(int argc, char const *argv[])
{
	printf("start!!!!\n");

	little_fs_config.context = calloc(1, LITTLE_FS_MAX_FILENAME + 1);

	memcpy(little_fs_config.context, LITTLE_CP_PATH, strlen(LITTLE_CP_PATH) );

	char str[256] = "hello good morning world!!!  is so cool!!!";   //最小操作读写快为#define LITTLE_FS_READ_SIZE (128) #define LITTLE_FS_PROGRAM_SIZE (128)

	char *rp = NULL;

	rp = calloc(0, LITTLE_FS_BLOCK_SIZE + 1);


	//First test
	//littlfs_program(&little_fs_config, 0, 0, str, LITTLE_FS_PROGRAM_SIZE);

	//littlfs_read(&little_fs_config, 0, 0, rp, LITTLE_FS_READ_SIZE);

	//printf("read data = %s\n", rp);

	//littlfs_erase(&little_fs_config, 0);


	int ret = mount_init(&little_fs, &little_fs_config);
	if (ret != LFS_ERR_OK)
	{
		printf("lfs_mount error=%d\n", ret);
		return 0;
	}

	ret = lfs_stat(&little_fs, "/", &dirlfsinfo);
	if (ret < LFS_ERR_OK)
	{
		printf("lfs_mount error=%d\n", ret);
		lfs_unmount(&little_fs);
		return 0;
	}

	printf("dirlfsinfo.type = %x, dirlfsinfo.size = %d, dirlfsinfo.name = %s\n", dirlfsinfo.type, dirlfsinfo.size, dirlfsinfo.name);

	ret = lfs_dir_open(&little_fs, &dir_data, "/");
	if (ret < LFS_ERR_OK){
		printf("lfs_dir_open error=%d\n", ret);
		lfs_unmount(&little_fs);
		return ret;
	}

	printf("dirlfsinfo.type = %x, dirlfsinfo.size = %d, dirlfsinfo.name = %s\n", dirlfsinfo.type, dirlfsinfo.size, dirlfsinfo.name);

	ret = lfs_stat(&little_fs, "/", &dirlfsinfo);
	if (ret < LFS_ERR_OK)
	{
		printf("lfs_mount error=%d\n", ret);
		lfs_dir_close(&little_fs, &dir_data);
		lfs_unmount(&little_fs);
		return 0;
	}

	printf("dirlfsinfo.type = %x, dirlfsinfo.size = %d, dirlfsinfo.name = %s\n", dirlfsinfo.type, dirlfsinfo.size, dirlfsinfo.name);

	ret = lfs_dir_open(&little_fs, &dir_data, "/");
	if (ret < LFS_ERR_OK){
		printf("lfs_dir_open error=%d\n", ret);
		lfs_unmount(&little_fs);
		return ret;
	}
	
	int i = 12;
	while(i--){
		ret = lfs_dir_read(&little_fs, &dir_data, &dirlfsinfo);
		if (ret < LFS_ERR_OK){
			printf("copy lfs_stat error=%d\n", ret);
			lfs_dir_close(&little_fs, &dir_data);
			lfs_unmount(&little_fs);
			return ret;
		}

		printf("dirlfsinfo.type = %x, dirlfsinfo.size = %d, dirlfsinfo.name = %s\n", dirlfsinfo.type, dirlfsinfo.size, dirlfsinfo.name);
	}

	lfs_soff_t index = lfs_dir_tell(&little_fs, &dir_data);
	if (index < 0)
	{
		printf("lfs_dir_tell error=%d\n", index);
		lfs_dir_close(&little_fs, &dir_data);
		lfs_unmount(&little_fs);
		return 0;
	}

	ret = lfs_dir_seek(&little_fs, &dir_data, index);
	if (ret < 0)
	{
		printf("lfs_dir_seek error=%d\n", ret);
		lfs_dir_close(&little_fs, &dir_data);
		lfs_unmount(&little_fs);
		return 0;
	}

	ret = lfs_dir_rewind(&little_fs, &dir_data);
	if (ret < 0)
	{
		printf("lfs_dir_rewind error=%d\n", ret);
		lfs_dir_close(&little_fs, &dir_data);
		lfs_unmount(&little_fs);
		return 0;
	}

	ret = lfs_dir_close(&little_fs, &dir_data);
	if (ret < 0)
	{
	  printf("lfs_dir_close error=%d\n", ret);
	  lfs_unmount(&little_fs);
	  return 0;
	}

	ret =  lfs_unmount(&little_fs);
	if (ret < 0)
	{
	  printf("lfs_unmount error=%d\n", ret);
	  return 0;
	}

	printf("end!!!!!\n");

	return 0;
}



int littlfs_read(const struct lfs_config *cfg, lfs_block_t block,
            lfs_off_t off, void *buffer, lfs_size_t size)
{

#ifdef DEBUG
	printf("littlfs_read(%p, %d, %d, %p, %d)\n",
            (void*)cfg, block, off, buffer, size);
#endif

	assert(off % cfg->read_size == 0);  //void assert( int expression );    它的条件返回错误，则终止程序执行
	assert(size % cfg->read_size == 0);
	assert(block < cfg->block_count);
	
	FILE* f = fopen(LITTLE_CP_PATH, "rb");
	if(f == NULL){
		f = fopen(LITTLE_CP_PATH, "wb");
		if(f == NULL){
			printf("littlfs_read fopen error\n");
			return -1;
		}

		int ret = fclose(f);
		if (ret < LFS_ERR_OK){
			printf("littlfs_read close error");
			return ret;
		}
	}
	else{
		int ret = fseek(f, block * cfg->block_size + off, SEEK_SET);
	    if (ret < LFS_ERR_OK) {
	        printf("littlfs_read -> %d\n", ret);
	        fclose(f);
	        return ret;
	    }

		size_t res = fread(buffer, 1, size, f);
		if (res < size) {	//int feof(FILE *stream); 如果文件结束，则返回非0值，否则返回0，文件结束符只能被clearerr()清除	  && !feof(f)
	        printf("littlfs_read fread -> %ld\n", res);
	        fclose(f);
	        return res;
	    }

	 //    ret = fclose(f);
		// if (ret < LFS_ERR_OK){
		// 	printf("littlfs_read close error");
		// 	return ret;
		// }
	}

//#ifdef DEBUG
    printf("lfs_read end!\n");
//#endif

	return 0;
}

int littlfs_program(const struct lfs_config *cfg, lfs_block_t block,
            lfs_off_t off, const void *buffer, lfs_size_t size)
{
#ifdef DEBUG
	printf("littlfs_program(%p, %d, %d, %p, %d)\n",
            (void*)cfg, block, off, buffer, size);
#endif

	//uint8_t* p_buffer = (char *)buffer;

	// Check if write is valid
    assert(off % cfg->prog_size == 0);
    assert(size % cfg->prog_size == 0);
    assert(block < cfg->block_count);

    FILE* f = fopen(LITTLE_CP_PATH, "r+b");
	if (f == NULL) {
		f = fopen(LITTLE_CP_PATH, "w+b");
		if(f == NULL){
			printf("lfs_program fopen create -> -1\n");
			return -1;
		}
	}

	int ret = fseek(f, block * cfg->block_size + off, SEEK_SET);
    if (ret < LFS_ERR_OK) {
        printf("lfs_program fseek -> %d\n", ret);
        fclose(f);
        return ret;
    }
		
    size_t res = fwrite(buffer, 1, size, f);   //从f读取大小size的字节数到data
    if (res < size) {	//int feof(FILE *stream); 如果文件结束，则返回非0值，否则返回0，文件结束符只能被clearerr()清除 
        printf("lfs_program fread -> %ld\n", res);
        fclose(f);
        return res;
    }

    ret = fclose(f);
    if (ret < LFS_ERR_OK) {
        printf("lfs_program fclose -> %d\n", ret);
        return ret;
    }
		
//#ifdef DEBUG
    printf("lfs_prog end!\n");
//#endif
    return 0;
}

int littlfs_erase(const struct lfs_config *cfg, lfs_block_t block)
{
	// Check if erase is valid
    // assert(block < cfg->block_count);
    //注意：num：对象个数，size：对象占据的内存字节数，相较于malloc函数，calloc函数会自动将内存初始化为0；
    char* perase = malloc(cfg->block_size + 1);  //void* calloc（unsigned int num，unsigned int size
    memset(perase, 255, cfg->block_size);

    FILE *f = fopen(LITTLE_CP_PATH, "w+b");
    if (f == NULL) {
        printf("littlfs_erase fopen -> -1\n");
        free(perase);
        return -1;
    }

    // Check that file was erased
    assert(f);

    int ret = fseek(f, block * cfg->block_size, SEEK_SET);
    if (ret < LFS_ERR_OK) {
        printf("littlfs_erase fseek -> %d\n", ret);
        free(perase);
        fclose(f);
        return ret;
    }

    size_t res = fwrite(perase, 1, cfg->block_size, f);
    if (res < cfg->block_size) {
        printf("littlfs_erase fwrite -> %ld\n", res);
        free(perase);
        fclose(f);
        return res;
    }

    ret = fclose(f);
    if (ret < LFS_ERR_OK) {
        printf("lfs_erase fclose -> %d\n", ret);
        free(perase);
        return ret;
    }

	free(perase);

#ifdef DEBUG
    printf("lfs_erase end!\n");
#endif

    return 0;
}

int littlfs_sync(const struct lfs_config *cfg)
{

#ifdef DEBUG
    printf("lfs_sync end!\n");
#endif

    return 0;
}